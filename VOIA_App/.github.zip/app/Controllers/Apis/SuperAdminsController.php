<?php

namespace App\Controllers\Apis;

use CodeIgniter\RESTful\ResourceController;

class SuperAdminsController extends ResourceController
{
    public function getAllSuperAdmin()
    {
        return $this->respond(["En construction"]);
    }
}
