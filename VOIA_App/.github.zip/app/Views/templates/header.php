<!DOCTYPE html>
<html>

<head>
  <title>VOIA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="/Css/bootstrap-materia.css">
  <link href="/Css/fontawesome/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="/Css/style.css">

  <script src="/JS/_vendor/jquery/dist/jquery.min.js"></script>
  <script src="/JS/config.js"></script>
  <script src="/JS/_vendor/popper.js/dist/umd/popper.min.js"></script>
  <script src="/JS/_vendor/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/JS/_assets/js/custom.js"></script>


</head>

<body>