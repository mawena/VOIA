</body>

<footer>
    <em class="pull-right">&copy; 2020</em>
</footer>

<script src="/JS/_vendor/jquery/dist/jquery.min.js"></script>
<script src="/JS/_vendor/popper.js/dist/umd/popper.min.js"></script>
<script src="/JS/_vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="/JS/_assets/js/custom.js"></script>
</html>