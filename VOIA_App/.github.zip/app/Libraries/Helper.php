<?php

namespace App\Libraries;

class Helper
{
    /**
     * Retourne l'url de base du site
     *
     * @return void
     */
    public static function getBaseUrl()
    {
        return "http://voia1.ghiyadaafrica.org";
    }
}
