<?php

namespace App\Models;

use CodeIgniter\Model;

class CountryModel extends Model
{
    protected $table = "Country";
    protected $primaryKey = "id";
}
