<?php

namespace App\Models;

use CodeIgniter\Model;

class ContinentModel extends Model
{
    protected $table = "Continent";
    protected $primaryKey = "id";
}
