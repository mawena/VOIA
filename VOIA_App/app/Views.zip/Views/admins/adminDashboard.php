<!-- <link href="/Css/font-awesome.css" rel="stylesheet"> -->
<!-- <script src="/JS/kit.font-awesome.js" crossorigin="anonymous"></script> -->
<link rel="stylesheet" href="/Css/dashboard.css">
<div class="body">
    <div class="wrapper">
        <div class="sidebar" style="background: grey;">
            <h2>Dashbord</h2>
            <ul>
                <li><a href="#membres"><i class="fas fa-people-arrows"> Membres</i></a></li>
            </ul>
        </div>
        <div class="main_content">
            <div class="header text-center">Page d'administraion des membres</div>
            <div class="info">
                <div>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laborum porro eveniet non cupiditate id dolore eligendi doloribus quidem itaque saepe quae commodi temporibus suscipit tempore inventore aspernatur ratione, aperiam expedita, quo voluptas. Perspiciatis, quas, quae ipsam aspernatur velit quisquam, accusantium ratione dolorum eligendi ullam natus. Consectetur repudiandae ipsam debitis deleniti.</div>
            </div>
        </div>
    </div>
</div>